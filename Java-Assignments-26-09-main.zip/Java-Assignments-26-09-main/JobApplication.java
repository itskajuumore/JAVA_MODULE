package Assignments;
import java.util.Scanner;
public class JobApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 Scanner sc=new Scanner(System.in);
 System.out.println("Person quali");
 String quali=sc.next();
 System.out.println("person Experience");
 String Experience= sc.next();
 System.out.print("Do you have a clean criminal record? (yes/no): ");
 String CleanRecord = sc.next();
 
 boolean Eligible = (quali.equalsIgnoreCase("yes") || Experience.equalsIgnoreCase("yes"))
         && CleanRecord.equalsIgnoreCase("yes");
 

if (Eligible)
{
    System.out.println("Best wishes! You are eligible for the job");
} 
else
{
    System.out.println("You are not eligible for the job");
}
	}
	
}

