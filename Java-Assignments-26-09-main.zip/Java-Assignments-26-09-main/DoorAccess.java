package Assignments;

import java.util.Scanner;

public class DoorAccess {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the ID of person");
		int personid = sc.nextInt();
		System.out.println("Enter the access card number");
		int cardNo = sc.nextInt();
		System.out.println("Enter Admin Name");
		String name = sc.next();

		int id = 301210;
		int card = 123456;
		String admin = "Kajal";

		if ((id == personid && card == cardNo) || (name.equals("admin"))) {
			System.out.println("Person is allowed to enter ");
		} else {
			System.out.println("Person is not allowed to enter");
		}

	}

	
}
//Output
//Enter the ID of person
//301210
//Enter the access card number
//123456
//Enter Admin Name
//kajal
//Person is allowed to enter 