package Assignments;
import java.util.Scanner;
public class Weather {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
System.out.print("Enter the temperature in °C ");
int temp = sc.nextInt();
System.out.print("Is it raining? (yes/no) ");
String isRaining = sc.next();
boolean safeToGoOutside = (temp >= 20 && temp <= 30) && !isRaining.equalsIgnoreCase("yes");
if (safeToGoOutside) {
    System.out.println("It's safe to go outside");
} 
else 
{
    System.out.println("It's not safe to go outside");
}
	}

}

//output=
//Enter the temperature in °C 25
//Is it raining? (yes/no) yes
//It's not safe to go outside
