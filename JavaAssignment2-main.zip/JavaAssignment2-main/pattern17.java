package Pattern;

public class pattern17 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         int row=5;
         int space=0;
         int star=4;
         for(int i=0; i<row; i++)
         {
        	 for(int j=0; j<space; j++)
        	 {
        		 System.out.println(" ");
        	 }
        	 for(int k=0; k<star; k++)
        	 {
        		 System.out.println();
        	 }
         }
	}

}
//output==
//54321
//5432
//543
//54
//5