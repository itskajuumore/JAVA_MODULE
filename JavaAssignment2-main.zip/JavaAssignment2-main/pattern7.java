package Pattern;

public class pattern7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=0;
		for (int i = 0; i <5; i++) {
			for (int j = 0; j <i; j++) {
				System.out.print((int)(a+i+j));  //(i+j)%2+" ");
			}
			System.out.println(" ");
		}
	}


	}
//output==
//1 
//23 
//345 
//4567 
