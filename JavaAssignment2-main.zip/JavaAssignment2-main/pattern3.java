package Pattern;

public class pattern3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int row = 5;
		int col = 5;
		for (int i = 1; i <row; i++) {
			for (int j = 1; j <col; j++) {
				System.out.print(j%2);
			}
			System.out.println(" ");
		}
	}

	}
//output==
//1010 
//1010 
//1010 
//1010 

