package Pattern;

public class pattern11 {

	public static void main(String[] args) {
int col=6;
int row=6;
int space=5;
int star=1;
for(int i=0; i<row; i++)
{
       for(int k=0; k<space; k++)
		{
			System.out.println();
		}
       for(int l=0; 1<star; l++)
       {
    	   System.out.println("*");
	}
       space--;
       star++;
       System.out.println(" ");
}
	}

}
