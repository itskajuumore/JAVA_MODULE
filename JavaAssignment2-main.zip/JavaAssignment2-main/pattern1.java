package Pattern;

public class pattern1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int row = 5;
		int col = 5;
		for (int i = 1; i <row; i++) {
			for (int j = 1; j <col; j++) {
				System.out.print(i);
			}
			System.out.println(" ");
		}
	}

	}
//output==
//1111 
//2222 
//3333 
//4444 

