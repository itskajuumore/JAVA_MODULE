package Pattern;

public class Pattern10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int row = 5;
		int col = 5;
		for (int i = 1; i < 5; i++) {
			for (int j = 1; j < 5; j++) {
				System.out.print(j);
			}
			System.out.println(" ");
		}
	}

}

//output==
//1234 
//1234 
//1234 
//1234 

