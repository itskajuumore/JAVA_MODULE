package ArrayAssignments;

import java.util.Arrays;

public class Acending_Decending {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = { 1, 90, 34, 89, 7, 9 };
		int n = arr.length;
		int mid = n / 2;
		Arrays.sort(arr);
		for (int i = mid; i < n; i++) {
			for (int j = i+1; j < n; j++) {
				if (arr[i] < arr[j]) {
					int temp = arr[i];
					arr[i] = arr[j];
					arr[j] = temp;
				}
			}

		}
		System.out.println("output:" + Arrays.toString(arr));
	}
}
//output==
//output:[1, 7, 9, 90, 89, 34]