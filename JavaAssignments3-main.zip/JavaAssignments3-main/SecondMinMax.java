package ArrayAssignments;

import java.util.Arrays;

public class SecondMinMax {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  int arr[]= {1,2,3,4,5,6,7,8};
   Arrays.sort(arr);
   int secondmin=arr[1];
   int secondmax=arr[arr.length-2];
   System.out.println("secondmin:"+secondmin);
   System.out.println("secondmax:"+secondmax);
	}

}
