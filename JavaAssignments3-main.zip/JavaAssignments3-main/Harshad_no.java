package ArrayAssignments;
import java.util.Scanner;

public class Harshad_no {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a num");
		int num = sc.nextInt();
		int originalNum = num;
		int sumofdigits = 0;
		while (num > 0) {
			int digits = num % 10;
			sumofdigits += digits;
			num = num / 10;
		}
		if (originalNum % sumofdigits == 0) {
			System.out.println(originalNum + "is a harshad number");
		} else {
			System.out.println(sumofdigits + "is not a harshad number");
		}

	}

}

//output==
//Enter a num
//24
//24is a harshad number
