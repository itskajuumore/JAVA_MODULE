package Assignment4;

import java.util.Scanner;

public class Testcpx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

        // Input first complex number
        System.out.print("Enter real part of first complex number: ");
        double r1 = sc.nextDouble();
        System.out.print("Enter imaginary part of first complex number: ");
        double i1 = sc.nextDouble();
        cpx c1 = new cpx(r1, i1);

        // Input second complex number
        System.out.print("Enter real part of second complex number: ");
        double r2 = sc.nextDouble();
        System.out.print("Enter imaginary part of second complex number: ");
        double i2 = sc.nextDouble();
        cpx c2 = new cpx(r2, i2);

        // Perform operations
        cpx sum = c1.add(c2);
        cpx diff = c1.sub(c2);
        cpx prod = c1.mul(c2);

        // Display results
        System.out.print("Sum: ");
        sum.show();
        System.out.print("Difference: ");
        diff.show();
        System.out.print("Product: ");
        prod.show();
	}

}
