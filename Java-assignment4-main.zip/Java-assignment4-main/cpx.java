package Assignment4;

public class cpx {
	private double r; // Real part
	private double i; // Imaginary part

	public cpx(double r, double i) {
		this.r = r;
		this.i = i;
	}

	public cpx add(cpx c) {
		return new cpx(this.r + c.r, this.i + c.i);
	}

	public cpx sub(cpx c) {
		return new cpx(this.r - c.r, this.i - c.i);
	}

	public cpx mul(cpx c) {
		return new cpx(this.r * c.r - this.i * c.i, this.r * c.i + this.i * c.r);
	}

	public void show() {
		{
			System.out.print(r);
			if (i >= 0) {
				System.out.print(" + " + i + "i");
			} else {
				System.out.print(" - " + Math.abs(i) + "i");
			}
			System.out.println();
		}
	}
}
