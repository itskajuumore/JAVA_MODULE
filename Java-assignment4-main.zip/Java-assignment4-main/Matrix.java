package Assignment4;

public class Matrix {
	private int r;
	private int c;
	private int[][] m;

	public Matrix(int rows, int cols) {
		r = rows;
		c = cols;
		m = new int[r][c];
	}

	public void set(int i, int j, int val) {
		if (i >= 0 && i < r && j >= 0 && j < c) {
			m[i][j] = val; // Set the element in the matrix
		} else {
			System.out.println("Invalid index!");
		}
	}

	public Matrix add(Matrix other) {
		if (this.r != other.r || this.c != other.c) {
			System.out.println("Matrices cannot be added.");
			return null;
		}

		Matrix result = new Matrix(r, c);
		for (int i = 0; i < r; i++) {
			for (int j = 0; j < c; j++) {
				result.m[i][j] = this.m[i][j] + other.m[i][j];
			}
		}
		return result;
	}

	public void display() {
		for (int i = 0; i < r; i++) {
			for (int j = 0; j < c; j++) {
				System.out.print(m[i][j] + " ");
			}
			System.out.println();
		}
	}
}
