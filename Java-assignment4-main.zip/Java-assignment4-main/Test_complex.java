package Assignment4;

import java.util.Scanner;

public class Test_complex {

	private static final complex c1 = null;
	private static final complex c2 = null;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number");
		double real1 = sc.nextDouble();
		System.out.print(" the imaginary part of the first complex number: ");
		double imaginary1 = sc.nextDouble();

		System.out.println("==========================================");
		System.out.print("the real part of the second complex number: ");
		double real2 = sc.nextDouble();
		System.out.print(" the imaginary part of the second complex number: ");
		double imaginary2 = sc.nextDouble();

		complex complex1 = new complex(0, 0);
		complex complex2 = new complex(0, 0);
		complex sum = c1.add(c2);
		complex sub = c1.sub(c2);
		complex product = c1.multiply(c2);

		System.out.print("Sum:");
		c1.add(c2).display();
		System.out.print("Difference:");
		c1.sub(c2).display();
		System.out.print("Product: ");
		c1.multiply(c2).display();

	}
}
