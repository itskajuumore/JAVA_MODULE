//Print the sum, difference and product of two complex numbers by creating a class, named 'Complex' with separate methods for each operation whose real and imaginary parts are entered by user. 
//Use Constructors to initialize the data members.

package Assignment4;

public class complex {
	private double real;
	private double imaginary;

	public complex(double real, double imaginary) {
		this.real = real;
		this.imaginary = imaginary;
	}

	complex add(complex c2) {
		double realsum = this.real + c2.real;
		double imaginarysum = this.imaginary + c2.imaginary;
		return new complex(realsum, imaginarysum);

	}

	complex sub(complex c2) {
		double realsub = this.real - c2.real;
		double imaginarysub = this.imaginary - c2.imaginary;
		return new complex(realsub, imaginarysub);
	}

	complex multiply(complex c2) {
		double realproduct = (this.real * c2.real) - (this.imaginary * c2.imaginary);
		double imaginaryproduct = (this.real * c2.real) - (this.imaginary * c2.imaginary);
		return new complex(realproduct, imaginaryproduct);
	}

	void display() {
		System.out.println(real + " + " + imaginary + "i");
	}

}
