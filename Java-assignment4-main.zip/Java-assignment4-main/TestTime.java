package Assignment4;

public class TestTime {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Time time1 = new Time(12, 30, 45);
		time1.display();

		Time time2 = new Time(25, 61, 70);
		time2.display();

		Time time3 = new Time();
		time3.display();
	}
}
