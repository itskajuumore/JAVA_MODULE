//Write a program to print the area and perimeter of a triangle having sides of 3, 4 and 5 
//units by creating a class named 'Triangle' with parameter in its constructor.

package Assignment4;

public class Triangle {
	private double sideA;
	private double sideB;
	private double sideC;

	public Triangle(double sideA, double sideB, double sideC) {
		super();
		this.sideA = sideA;
		this.sideB = sideB;
		this.sideC = sideC;
	}

	public double Perimeter() {
		return sideA + sideB + sideC;
	}

	public double Area() {
		double s = Perimeter() / 2; // Hero's formula
		return Math.sqrt(s * (s - sideA) * (s - sideB) * (s - sideC));
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Triangle triangle = new Triangle(3, 4, 5);
		System.out.println("Area of triangle:" + triangle.Area());
		System.out.println("perimeter of triangle:" + triangle.Perimeter());
	}
}
